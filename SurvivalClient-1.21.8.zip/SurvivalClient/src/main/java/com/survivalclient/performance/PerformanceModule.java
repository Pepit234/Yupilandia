package com.survivalclient.performance;

import com.survivalclient.core.Module;
import net.minecraft.client.MinecraftClient;

/**
 * Optimizaciones seguras y control de actualizaciones.
 * No modifica el render del mundo de forma ilegal.
 */
public class PerformanceModule implements Module {

	private boolean enabled = true;

	@Override
	public String getName() {
		return "Rendimiento";
	}

	@Override
	public String getDescription() {
		return "Reduce actualizaciones innecesarias y libera recursos cuando los módulos están desactivados.";
	}

	@Override
	public boolean isEnabled() {
		return enabled;
	}

	@Override
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	@Override
	public String getCategory() {
		return "Rendimiento";
	}

	@Override
	public void onClientTick(MinecraftClient client) {
		// Aquí se pueden poner contadores o perfiles ligeros
	}
}
