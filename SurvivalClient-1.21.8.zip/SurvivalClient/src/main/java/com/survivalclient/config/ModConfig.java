package com.survivalclient.config;

import java.util.ArrayList;
import java.util.List;

/**
 * Modelo de configuración serializable.
 * Contiene todas las preferencias del usuario.
 */
public class ModConfig {

	// === HUD ===
	public boolean hudEnabled = true;
	public boolean showCoordinates = true;
	public boolean showDirection = true;
	public boolean showFps = true;
	public boolean showPing = true;
	public boolean showHealth = true;
	public boolean showHunger = true;
	public boolean showArmor = true;
	public boolean showDurability = true;
	public boolean showEffects = true;
	public boolean showWorldTime = true;
	public boolean showDimension = true;
	public boolean showBiome = true;

	public int hudX = 4;
	public int hudY = 4;
	public float hudScale = 1.0f;
	public float hudOpacity = 0.85f;
	public int hudColor = 0xFFFFFF;

	// === Waypoints ===
	public boolean waypointsEnabled = true;
	public boolean showWaypointDistance = true;
	public boolean showWaypointOnHud = true;

	// === Survival / Inventory ===
	public boolean durabilityWarnings = true;
	public int durabilityWarningThreshold = 10; // %
	public boolean showSelectedItem = true;

	// === Performance ===
	public boolean reduceUpdatesWhenClosed = true;
	public int maxHudUpdateRate = 20; // ticks

	// === Keybinds (se guardan por separado en options, pero podemos tener preferencias) ===
	public boolean openMenuOnRightShift = true;

	// === Waypoints data (se guarda también en archivo separado si se desea) ===
	public List<WaypointData> waypoints = new ArrayList<>();

	public static class WaypointData {
		public String name = "Nuevo";
		public double x, y, z;
		public String dimension = "overworld";
		public int color = 0x00FF00;
		public boolean enabled = true;
		public String icon = "default";

		public WaypointData() {}

		public WaypointData(String name, double x, double y, double z, String dimension, int color) {
			this.name = name;
			this.x = x;
			this.y = y;
			this.z = z;
			this.dimension = dimension;
			this.color = color;
		}
	}
}
