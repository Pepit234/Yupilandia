package com.survivalclient.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;
import com.survivalclient.core.SurvivalClient;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Gestión de configuración local.
 * Archivo: config/survivalclient.json
 * Valida al cargar y usa valores por defecto si está corrupto.
 * Nunca lee datos sensibles (tokens, sesiones, etc.).
 */
public class ConfigManager {

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private final Path configPath;
	private ModConfig config;

	public ConfigManager() {
		this.configPath = FabricLoader.getInstance().getConfigDir().resolve("survivalclient.json");
		this.config = new ModConfig(); // valores por defecto
	}

	public void load() {
		if (!Files.exists(configPath)) {
			save();
			SurvivalClient.LOGGER.info("Archivo de configuración creado: {}", configPath);
			return;
		}

		try {
			String json = Files.readString(configPath);
			ModConfig loaded = GSON.fromJson(json, ModConfig.class);
			if (loaded != null) {
				this.config = loaded;
				SurvivalClient.LOGGER.info("Configuración cargada correctamente.");
			} else {
				SurvivalClient.LOGGER.warn("Configuración inválida, usando valores por defecto.");
				save();
			}
		} catch (IOException | JsonSyntaxException e) {
			SurvivalClient.LOGGER.error("Error al cargar configuración. Usando valores por defecto.", e);
			this.config = new ModConfig();
			save();
		}
	}

	public void save() {
		try {
			Files.createDirectories(configPath.getParent());
			Files.writeString(configPath, GSON.toJson(config));
		} catch (IOException e) {
			SurvivalClient.LOGGER.error("No se pudo guardar la configuración.", e);
		}
	}

	public ModConfig getConfig() {
		return config;
	}
}
