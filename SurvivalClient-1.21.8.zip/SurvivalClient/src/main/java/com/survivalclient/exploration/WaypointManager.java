package com.survivalclient.exploration;

import com.survivalclient.config.ModConfig;
import com.survivalclient.core.SurvivalClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Gestión de waypoints legítimos.
 * Solo usa coordenadas conocidas por el jugador.
 * Guardado local. Sin escaneo del mundo ni X-Ray.
 */
public class WaypointManager {

	private final List<Waypoint> waypoints = new ArrayList<>();

	public void load() {
		waypoints.clear();
		ModConfig cfg = SurvivalClient.INSTANCE.getConfigManager().getConfig();
		for (ModConfig.WaypointData data : cfg.waypoints) {
			Waypoint wp = new Waypoint(data.name, data.x, data.y, data.z, data.dimension, data.color);
			wp.setEnabled(data.enabled);
			wp.setIcon(data.icon != null ? data.icon : "default");
			waypoints.add(wp);
		}
	}

	public void save() {
		ModConfig cfg = SurvivalClient.INSTANCE.getConfigManager().getConfig();
		cfg.waypoints.clear();
		for (Waypoint wp : waypoints) {
			ModConfig.WaypointData data = new ModConfig.WaypointData(
					wp.getName(), wp.getX(), wp.getY(), wp.getZ(),
					wp.getDimension(), wp.getColor()
			);
			data.enabled = wp.isEnabled();
			data.icon = wp.getIcon();
			cfg.waypoints.add(data);
		}
		SurvivalClient.INSTANCE.getConfigManager().save();
	}

	public void add(Waypoint waypoint) {
		waypoints.add(waypoint);
		save();
	}

	public void addAtPlayer(String name, int color) {
		MinecraftClient client = MinecraftClient.getInstance();
		if (client.player == null || client.world == null) return;

		BlockPos pos = client.player.getBlockPos();
		String dim = client.world.getRegistryKey().getValue().getPath();
		add(new Waypoint(name, pos, dim, color));
	}

	public void remove(Waypoint waypoint) {
		waypoints.remove(waypoint);
		save();
	}

	public void removeByName(String name) {
		waypoints.removeIf(w -> w.getName().equalsIgnoreCase(name));
		save();
	}

	public List<Waypoint> getWaypoints() {
		return new ArrayList<>(waypoints);
	}

	public Optional<Waypoint> getByName(String name) {
		return waypoints.stream()
				.filter(w -> w.getName().equalsIgnoreCase(name))
				.findFirst();
	}

	public void onClientTick(MinecraftClient client) {
		// Aquí se podrían actualizar distancias o notificaciones
		// de forma ligera si es necesario
	}

	/** Ejemplos predefinidos comunes de supervivencia */
	public void addDefaultExamples() {
		// Solo se añaden si el usuario lo pide explícitamente
	}
}
