package com.survivalclient.exploration;

import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class Waypoint {
	private String name;
	private double x, y, z;
	private String dimension;
	private int color;
	private boolean enabled;
	private String icon;

	public Waypoint(String name, double x, double y, double z, String dimension, int color) {
		this.name = name;
		this.x = x;
		this.y = y;
		this.z = z;
		this.dimension = dimension;
		this.color = color;
		this.enabled = true;
		this.icon = "default";
	}

	public Waypoint(String name, BlockPos pos, String dimension, int color) {
		this(name, pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, dimension, color);
	}

	public double distanceTo(Vec3d pos) {
		double dx = x - pos.x;
		double dy = y - pos.y;
		double dz = z - pos.z;
		return Math.sqrt(dx * dx + dy * dy + dz * dz);
	}

	public double distanceToHorizontal(Vec3d pos) {
		double dx = x - pos.x;
		double dz = z - pos.z;
		return Math.sqrt(dx * dx + dz * dz);
	}

	// Getters y setters
	public String getName() { return name; }
	public void setName(String name) { this.name = name; }

	public double getX() { return x; }
	public double getY() { return y; }
	public double getZ() { return z; }

	public void setPosition(double x, double y, double z) {
		this.x = x;
		this.y = y;
		this.z = z;
	}

	public String getDimension() { return dimension; }
	public void setDimension(String dimension) { this.dimension = dimension; }

	public int getColor() { return color; }
	public void setColor(int color) { this.color = color; }

	public boolean isEnabled() { return enabled; }
	public void setEnabled(boolean enabled) { this.enabled = enabled; }

	public String getIcon() { return icon; }
	public void setIcon(String icon) { this.icon = icon; }
}
