package com.survivalclient.exploration;

import com.survivalclient.core.Module;
import com.survivalclient.core.SurvivalClient;
import net.minecraft.client.MinecraftClient;

public class ExplorationModule implements Module {

	private boolean enabled = true;

	@Override
	public String getName() {
		return "Exploración";
	}

	@Override
	public String getDescription() {
		return "Waypoints, brújula y herramientas de exploración legítimas.";
	}

	@Override
	public boolean isEnabled() {
		return enabled && SurvivalClient.INSTANCE.getConfigManager().getConfig().waypointsEnabled;
	}

	@Override
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
		SurvivalClient.INSTANCE.getConfigManager().getConfig().waypointsEnabled = enabled;
		SurvivalClient.INSTANCE.getConfigManager().save();
	}

	@Override
	public String getCategory() {
		return "Exploración";
	}

	@Override
	public void onClientTick(MinecraftClient client) {
		// Lógica ligera de exploración si es necesario
	}
}
