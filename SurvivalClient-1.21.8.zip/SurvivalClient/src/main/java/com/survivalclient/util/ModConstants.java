package com.survivalclient.util;

import net.minecraft.util.Identifier;

public final class ModConstants {
	public static final String MOD_ID = "survivalclient";
	public static final String MOD_NAME = "Survival Client";
	public static final String VERSION = "1.0.0";
	public static final String MC_VERSION = "1.21.8";

	public static Identifier id(String path) {
		return Identifier.of(MOD_ID, path);
	}

	private ModConstants() {}
}
