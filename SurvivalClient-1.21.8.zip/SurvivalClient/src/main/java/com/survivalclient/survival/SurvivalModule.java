package com.survivalclient.survival;

import com.survivalclient.core.Module;
import com.survivalclient.core.SurvivalClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;

public class SurvivalModule implements Module {

	private boolean enabled = true;
	private int tickCounter = 0;

	@Override
	public String getName() {
		return "Supervivencia";
	}

	@Override
	public String getDescription() {
		return "Avisos de durabilidad baja, estado del jugador y alertas configurables.";
	}

	@Override
	public boolean isEnabled() {
		return enabled;
	}

	@Override
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	@Override
	public String getCategory() {
		return "Supervivencia";
	}

	@Override
	public void onClientTick(MinecraftClient client) {
		if (client.player == null) return;

		tickCounter++;
		// Revisamos cada 40 ticks (~2 segundos) para no saturar
		if (tickCounter < 40) return;
		tickCounter = 0;

		var cfg = SurvivalClient.INSTANCE.getConfigManager().getConfig();
		if (!cfg.durabilityWarnings) return;

		checkDurability(client.player.getMainHandStack(), "mano principal", cfg.durabilityWarningThreshold);
		checkDurability(client.player.getOffHandStack(), "mano secundaria", cfg.durabilityWarningThreshold);

		for (ItemStack armor : client.player.getArmorItems()) {
			checkDurability(armor, "armadura", cfg.durabilityWarningThreshold);
		}
	}

	private void checkDurability(ItemStack stack, String slot, int thresholdPercent) {
		if (stack.isEmpty() || !stack.isDamageable()) return;

		int max = stack.getMaxDamage();
		if (max <= 0) return;

		int remaining = max - stack.getDamage();
		int percent = (remaining * 100) / max;

		if (percent <= thresholdPercent && percent > 0) {
			// Aviso legítimo en el chat (o se puede hacer en HUD)
			MinecraftClient.getInstance().player.sendMessage(
					Text.literal("§e[Survival] §f" + stack.getName().getString() +
							" (" + slot + ") tiene solo " + percent + "% de durabilidad."),
					true // action bar
			);
		}
	}
}
