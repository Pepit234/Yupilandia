package com.survivalclient.hud;

import com.survivalclient.config.ModConfig;
import com.survivalclient.core.SurvivalClient;
import com.survivalclient.util.ModConstants;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.RegistryKey;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.dimension.DimensionType;

import java.util.Collection;

/**
 * Gestor del HUD legítimo.
 * Usa la API oficial HudElementRegistry de Fabric (1.21.6+).
 * Todos los datos se obtienen de APIs públicas del cliente.
 */
public class HudManager {

	public void init() {
		// Registramos nuestro elemento de HUD después de los overlays principales
		HudElementRegistry.attachElementAfter(
				VanillaHudElements.MISC_OVERLAYS,
				ModConstants.id("survival_hud"),
				this::render
		);
	}

	private void render(DrawContext context, RenderTickCounter tickCounter) {
		MinecraftClient client = MinecraftClient.getInstance();
		if (client.player == null || client.world == null || client.options.hudHidden) {
			return;
		}

		ModConfig cfg = SurvivalClient.INSTANCE.getConfigManager().getConfig();
		if (!cfg.hudEnabled) return;

		int x = cfg.hudX;
		int y = cfg.hudY;
		int color = cfg.hudColor;
		float scale = cfg.hudScale;

		// Aplicamos escala si es necesario (simplificado)
		context.getMatrices().push();
		if (scale != 1.0f) {
			context.getMatrices().scale(scale, scale, 1.0f);
		}

		int line = 0;
		int lineHeight = 10;

		// Coordenadas
		if (cfg.showCoordinates) {
			BlockPos pos = client.player.getBlockPos();
			draw(context, x, y + line * lineHeight, color,
					String.format("XYZ: %d / %d / %d", pos.getX(), pos.getY(), pos.getZ()));
			line++;
		}

		// Dirección
		if (cfg.showDirection) {
			Direction dir = client.player.getHorizontalFacing();
			String facing = switch (dir) {
				case NORTH -> "Norte (-Z)";
				case SOUTH -> "Sur (+Z)";
				case WEST -> "Oeste (-X)";
				case EAST -> "Este (+X)";
				default -> dir.asString();
			};
			draw(context, x, y + line * lineHeight, color, "Dir: " + facing);
			line++;
		}

		// FPS
		if (cfg.showFps) {
			draw(context, x, y + line * lineHeight, color, "FPS: " + client.getCurrentFps());
			line++;
		}

		// Ping (si está en multiplayer)
		if (cfg.showPing && client.getNetworkHandler() != null) {
			var entry = client.getNetworkHandler().getPlayerListEntry(client.player.getUuid());
			if (entry != null) {
				draw(context, x, y + line * lineHeight, color, "Ping: " + entry.getLatency() + " ms");
				line++;
			}
		}

		// Vida y hambre
		if (cfg.showHealth) {
			float health = client.player.getHealth();
			float maxHealth = client.player.getMaxHealth();
			draw(context, x, y + line * lineHeight, color,
					String.format("Vida: %.1f / %.1f", health, maxHealth));
			line++;
		}

		if (cfg.showHunger) {
			int food = client.player.getHungerManager().getFoodLevel();
			float saturation = client.player.getHungerManager().getSaturationLevel();
			draw(context, x, y + line * lineHeight, color,
					String.format("Hambre: %d (sat %.1f)", food, saturation));
			line++;
		}

		// Armadura
		if (cfg.showArmor) {
			int armor = client.player.getArmor();
			draw(context, x, y + line * lineHeight, color, "Armadura: " + armor);
			line++;
		}

		// Dimensión
		if (cfg.showDimension) {
			RegistryKey<DimensionType> dim = client.world.getDimensionEntry().getKey().orElse(null);
			String dimName = dim != null ? dim.getValue().getPath() : "desconocida";
			draw(context, x, y + line * lineHeight, color, "Dim: " + dimName);
			line++;
		}

		// Bioma (API legítima)
		if (cfg.showBiome) {
			Biome biome = client.world.getBiome(client.player.getBlockPos()).value();
			// Nombre del bioma (simplificado, en producción usar registry)
			draw(context, x, y + line * lineHeight, color, "Bioma: " + biome.toString().substring(0, Math.min(30, biome.toString().length())));
			line++;
		}

		// Hora del mundo
		if (cfg.showWorldTime) {
			long time = client.world.getTimeOfDay() % 24000;
			int hours = (int) ((time / 1000 + 6) % 24);
			int minutes = (int) ((time % 1000) * 60 / 1000);
			draw(context, x, y + line * lineHeight, color,
					String.format("Hora: %02d:%02d", hours, minutes));
			line++;
		}

		// Objeto seleccionado + durabilidad
		if (cfg.showSelectedItem || cfg.showDurability) {
			ItemStack stack = client.player.getMainHandStack();
			if (!stack.isEmpty()) {
				String itemName = stack.getName().getString();
				if (cfg.showDurability && stack.isDamageable()) {
					int max = stack.getMaxDamage();
					int dmg = stack.getDamage();
					int remaining = max - dmg;
					int percent = max > 0 ? (remaining * 100 / max) : 100;
					draw(context, x, y + line * lineHeight, color,
							String.format("%s [%d%%]", itemName, percent));
				} else if (cfg.showSelectedItem) {
					draw(context, x, y + line * lineHeight, color, itemName);
				}
				line++;
			}
		}

		// Efectos activos
		if (cfg.showEffects) {
			Collection<StatusEffectInstance> effects = client.player.getStatusEffects();
			if (!effects.isEmpty()) {
				draw(context, x, y + line * lineHeight, color, "Efectos:");
				line++;
				for (StatusEffectInstance effect : effects) {
					int seconds = effect.getDuration() / 20;
					String name = effect.getEffectType().value().getName().getString();
					draw(context, x + 4, y + line * lineHeight, 0xAAAAFF,
							String.format("- %s %ds", name, seconds));
					line++;
				}
			}
		}

		context.getMatrices().pop();
	}

	private void draw(DrawContext context, int x, int y, int color, String text) {
		context.drawTextWithShadow(MinecraftClient.getInstance().textRenderer, text, x, y, color);
	}
}
