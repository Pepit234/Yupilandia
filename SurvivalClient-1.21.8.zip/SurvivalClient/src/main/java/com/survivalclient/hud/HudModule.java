package com.survivalclient.hud;

import com.survivalclient.core.Module;
import com.survivalclient.core.SurvivalClient;
import net.minecraft.client.MinecraftClient;

public class HudModule implements Module {

	private boolean enabled = true;

	@Override
	public String getName() {
		return "HUD";
	}

	@Override
	public String getDescription() {
		return "Muestra coordenadas, FPS, vida, hambre, efectos y más información útil en pantalla.";
	}

	@Override
	public boolean isEnabled() {
		return enabled && SurvivalClient.INSTANCE.getConfigManager().getConfig().hudEnabled;
	}

	@Override
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
		SurvivalClient.INSTANCE.getConfigManager().getConfig().hudEnabled = enabled;
		SurvivalClient.INSTANCE.getConfigManager().save();
	}

	@Override
	public String getCategory() {
		return "HUD";
	}

	@Override
	public void onClientTick(MinecraftClient client) {
		// El render se hace en HudManager vía HudElementRegistry
	}
}
