package com.survivalclient.building;

import com.survivalclient.core.Module;
import net.minecraft.client.MinecraftClient;

/**
 * Módulo de construcción.
 * Calculadora de materiales y notas de proyectos.
 * NO automatiza colocación ni destrucción de bloques.
 */
public class BuildingModule implements Module {

	private boolean enabled = true;

	@Override
	public String getName() {
		return "Construcción";
	}

	@Override
	public String getDescription() {
		return "Calculadora de materiales, listas de bloques y notas de proyectos (manual).";
	}

	@Override
	public boolean isEnabled() {
		return enabled;
	}

	@Override
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	@Override
	public String getCategory() {
		return "Construcción";
	}

	@Override
	public void onClientTick(MinecraftClient client) {
		// Sin automatización de building.
	}
}
