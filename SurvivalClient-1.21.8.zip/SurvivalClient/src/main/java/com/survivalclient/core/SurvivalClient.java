package com.survivalclient.core;

import com.survivalclient.config.ConfigManager;
import com.survivalclient.exploration.WaypointManager;
import com.survivalclient.hud.HudManager;
import com.survivalclient.ui.KeyBindings;
import com.survivalclient.util.ModConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Entrypoint principal del cliente de supervivencia.
 * Solo se ejecuta en el lado cliente.
 * Arquitectura modular: cada módulo se inicializa aquí y se puede activar/desactivar.
 */
public class SurvivalClient implements ClientModInitializer {

	public static final Logger LOGGER = LoggerFactory.getLogger(ModConstants.MOD_ID);
	public static SurvivalClient INSTANCE;

	private ModuleManager moduleManager;
	private ConfigManager configManager;
	private HudManager hudManager;
	private WaypointManager waypointManager;

	@Override
	public void onInitializeClient() {
		INSTANCE = this;
		LOGGER.info("Inicializando Survival Client para Minecraft 1.21.8...");

		// 1. Configuración local (siempre primero)
		this.configManager = new ConfigManager();
		this.configManager.load();

		// 2. Sistema de módulos
		this.moduleManager = new ModuleManager();
		this.moduleManager.registerDefaultModules();

		// 3. HUD
		this.hudManager = new HudManager();
		this.hudManager.init();

		// 4. Waypoints (exploración)
		this.waypointManager = new WaypointManager();
		this.waypointManager.load();

		// 5. Keybindings
		KeyBindings.register();

		// Tick del cliente (para actualizaciones ligeras)
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			if (client.player != null && client.world != null) {
				moduleManager.onClientTick(client);
				waypointManager.onClientTick(client);
			}
		});

		LOGGER.info("Survival Client listo. Módulos cargados: {}", moduleManager.getEnabledCount());
	}

	public ModuleManager getModuleManager() {
		return moduleManager;
	}

	public ConfigManager getConfigManager() {
		return configManager;
	}

	public HudManager getHudManager() {
		return hudManager;
	}

	public WaypointManager getWaypointManager() {
		return waypointManager;
	}
}
