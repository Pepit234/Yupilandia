package com.survivalclient.core;

import net.minecraft.client.MinecraftClient;

/**
 * Interfaz base para todos los módulos del cliente.
 * Cada módulo (HUD, Survival, Exploration, etc.) implementa esta interfaz.
 */
public interface Module {

	String getName();

	String getDescription();

	boolean isEnabled();

	void setEnabled(boolean enabled);

	/** Llamado cuando el módulo se activa */
	default void onEnable() {}

	/** Llamado cuando el módulo se desactiva */
	default void onDisable() {}

	/** Tick del cliente (solo si está habilitado) */
	default void onClientTick(MinecraftClient client) {}

	/** Categoría para el menú de configuración */
	default String getCategory() {
		return "General";
	}
}
