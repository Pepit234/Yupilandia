package com.survivalclient.core;

import com.survivalclient.hud.HudModule;
import com.survivalclient.exploration.ExplorationModule;
import com.survivalclient.survival.SurvivalModule;
import com.survivalclient.inventory.InventoryModule;
import com.survivalclient.building.BuildingModule;
import com.survivalclient.performance.PerformanceModule;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

/**
 * Gestiona el ciclo de vida de todos los módulos.
 * Diseño modular: se pueden añadir/quitar módulos fácilmente.
 */
public class ModuleManager {

	private final List<Module> modules = new ArrayList<>();

	public void registerDefaultModules() {
		register(new HudModule());
		register(new SurvivalModule());
		register(new ExplorationModule());
		register(new InventoryModule());
		register(new BuildingModule());
		register(new PerformanceModule());
	}

	public void register(Module module) {
		modules.add(module);
		if (module.isEnabled()) {
			module.onEnable();
		}
	}

	public void onClientTick(MinecraftClient client) {
		for (Module module : modules) {
			if (module.isEnabled()) {
				module.onClientTick(client);
			}
		}
	}

	public List<Module> getModules() {
		return Collections.unmodifiableList(modules);
	}

	public Optional<Module> getModule(String name) {
		return modules.stream()
				.filter(m -> m.getName().equalsIgnoreCase(name))
				.findFirst();
	}

	public int getEnabledCount() {
		return (int) modules.stream().filter(Module::isEnabled).count();
	}

	public void toggle(String name) {
		getModule(name).ifPresent(m -> {
			boolean newState = !m.isEnabled();
			m.setEnabled(newState);
			if (newState) m.onEnable();
			else m.onDisable();
		});
	}
}
