package com.survivalclient.inventory;

import com.survivalclient.core.Module;
import net.minecraft.client.MinecraftClient;

public class InventoryModule implements Module {

	private boolean enabled = true;

	@Override
	public String getName() {
		return "Inventario";
	}

	@Override
	public String getDescription() {
		return "Información del inventario, objeto seleccionado y listas de recursos (solo lectura).";
	}

	@Override
	public boolean isEnabled() {
		return enabled;
	}

	@Override
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	@Override
	public String getCategory() {
		return "Inventario";
	}

	@Override
	public void onClientTick(MinecraftClient client) {
		// Solo lectura de inventario. Nunca se modifican ni generan items.
	}
}
