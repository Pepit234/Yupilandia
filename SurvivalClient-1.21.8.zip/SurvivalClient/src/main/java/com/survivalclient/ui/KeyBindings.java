package com.survivalclient.ui;

import com.survivalclient.core.SurvivalClient;
import com.survivalclient.exploration.WaypointManager;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/**
 * Atajos de teclado legítimos.
 */
public class KeyBindings {

	public static KeyBinding openMenuKey;
	public static KeyBinding addWaypointKey;
	public static KeyBinding toggleHudKey;

	public static void register() {
		openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.survivalclient.open_menu",
				InputUtil.Type.KEYSYM,
				GLFW.GLFW_KEY_RIGHT_SHIFT,
				"category.survivalclient.general"
		));

		addWaypointKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.survivalclient.add_waypoint",
				InputUtil.Type.KEYSYM,
				GLFW.GLFW_KEY_B,
				"category.survivalclient.general"
		));

		toggleHudKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.survivalclient.toggle_hud",
				InputUtil.Type.KEYSYM,
				GLFW.GLFW_KEY_H,
				"category.survivalclient.general"
		));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (openMenuKey.wasPressed()) {
				// Abrir menú (por ahora mensaje, se puede expandir a Screen)
				if (client.player != null) {
					client.player.sendMessage(
							net.minecraft.text.Text.literal("§a[Survival Client] §fMenú de configuración (próximamente Screen completa)"),
							false
					);
				}
			}

			while (addWaypointKey.wasPressed()) {
				if (client.player != null) {
					WaypointManager wm = SurvivalClient.INSTANCE.getWaypointManager();
					wm.addAtPlayer("Waypoint " + (wm.getWaypoints().size() + 1), 0x00FF00);
					client.player.sendMessage(
							net.minecraft.text.Text.literal("§a[Survival] §fWaypoint añadido en tu posición actual."),
							true
					);
				}
			}

			while (toggleHudKey.wasPressed()) {
				var cfg = SurvivalClient.INSTANCE.getConfigManager().getConfig();
				cfg.hudEnabled = !cfg.hudEnabled;
				SurvivalClient.INSTANCE.getConfigManager().save();
				if (client.player != null) {
					client.player.sendMessage(
							net.minecraft.text.Text.literal("§a[Survival] §fHUD " + (cfg.hudEnabled ? "activado" : "desactivado")),
							true
					);
				}
			}
		});
	}
}
